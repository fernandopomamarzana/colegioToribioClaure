Symbola-Emoji
=============

A ttf/woff/eot font for use with css.


---

Original code: https://coderwall.com/p/ruv9hq, look there for instructions on how to use this from css.
